       

<!DOCTYPE html>
	
<html lang="en">
    <head>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			
            <!--<title> Vel Tech - Entrepreneur Registration 2019</title>-->
            <title> Entrepreneur meet - 31st Aug 2019</title>

			<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
			<link href="/assets/css/custom.css" rel="stylesheet">
			<link rel="stylesheet" href="custom.css" />
	
			   
		    <style>
.final_bton {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  cursor: pointer;
  
}



.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}


</style>
        
        		
    </head>
		
<body>  
    
          
          <table border="0" align="center">
            
            <tr>
                <td colspan="2">
                    <img src="assets/img/logo.jpg" alt="veltech logo" />
                </td>
            </tr>
            
            <tr><td></td></tr>
            <tr><td></td></tr>
            
            <tr>
                <td align="center" colspan="2">
                    <h3> <u>Entrepreneur Online Registration 2019</u> </h3>
                </td>
            </tr>
            <tr>
                <td><h2>Dear Candidate, Your details have been collected successfully. Thank you. </h2></td>
            </tr>
                    
          
        </table>
        
        
        
        
    <br/>
    <p style="padding-left:10px;"><strong>Contact</strong><br>
Ms. Kasthuri .D,<br>
<strong>Alumni Officer</strong><br>
Skype ID : veltech.alumnus<br>
facebook : <a href="https://www.facebook.com/veltech.alumnus.7" target="_blank" rel="noopener">https://www.facebook.com/veltech.alumnus.7</a><br>
facebook name : Veltech Alumnus
LinkedIn : <a href="https://www.linkedin.com/in/veltech-alumnus-318502176" target="_blank" rel="noopener">https://www.linkedin.com/in/veltech-alumnus-318502176</a><br>
Contact No  :09677 763 280<br>
Email Id: <a href="mailto:alumni@veltech.edu.in">alumni@veltech.edu.in</a></p>
    
    <p style="text-align:center;"><a href="http://veltech.edu.in/alumnimeet/entrepreneur/view.php"><button class="final_bton button2">View Vel Tech Entrepreneur Details</button></a></p>
    
    

	 
				

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 



</body>
</html>